export const colors = {
  primary: "#f76c6c",
  focus: {
    h: 45,
    s: "100%",
    l: "42%",
  },
};
